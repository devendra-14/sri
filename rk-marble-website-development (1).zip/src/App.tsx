import { useMemo, useState } from "react";
import { marbles, CONTACT, type Marble } from "./data";

function download(m: Marble) {
  fetch(m.img)
    .then((r) => r.blob())
    .then((b) => {
      const url = URL.createObjectURL(b);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${m.id}-rk-marble-sirohi.jpg`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    })
    .catch(() => window.open(m.img, "_blank"));
}

export default function App() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [view, setView] = useState<Marble | null>(null);

  const cats = useMemo(() => ["All", ...Array.from(new Set(marbles.map((m) => m.type)))], []);
  const list = marbles.filter(
    (m) =>
      (cat === "All" || m.type === cat) &&
      (m.name + m.origin + m.type).toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-stone-50 text-stone-800">
      {/* Nav */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-stone-200">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-stone-700 to-stone-900 text-white grid place-items-center font-bold">RK</div>
            <div>
              <p className="font-bold leading-tight">RK Marble</p>
              <p className="text-xs text-stone-500 leading-tight">Sirohi, Rajasthan</p>
            </div>
          </div>
          <a href={`tel:${CONTACT.phone}`} className="px-4 py-2 rounded-full bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700">
            📞 {CONTACT.phone}
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative">
        <img src={marbles[4].img} alt="marble" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-stone-900/90 to-stone-900/50" />
        <div className="relative max-w-6xl mx-auto px-4 py-24 text-white">
          <p className="uppercase tracking-[0.3em] text-amber-300 text-xs mb-3">Since generations in Sirohi</p>
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">RK Marble Sirohi</h1>
          <p className="mt-4 max-w-xl text-stone-200">
            Supplier of all types of Indian marble — Makrana, Ambaji, Banswara, Katni Beige, Green,
            Onyx & Black Marquina. Browse the gallery and download any marble photo free.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#gallery" className="px-6 py-3 rounded-full bg-amber-400 text-stone-900 font-semibold">View Marble Gallery</a>
            <a href={`https://wa.me/91${CONTACT.phone}`} target="_blank" className="px-6 py-3 rounded-full border border-white/50 font-semibold">WhatsApp Devendra</a>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-6xl mx-auto px-4 -mt-10 relative z-10 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[["12+", "Marble Varieties"], ["25+", "Years Experience"], ["100%", "Natural Stone"], ["PAN", "India Delivery"]].map(([a, b]) => (
          <div key={b} className="bg-white rounded-xl shadow p-4 text-center">
            <p className="text-2xl font-bold text-stone-900">{a}</p>
            <p className="text-xs text-stone-500">{b}</p>
          </div>
        ))}
      </section>

      {/* Gallery */}
      <section id="gallery" className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold">All Marble Present in India</h2>
        <p className="text-stone-500 mt-1">Click download to save any marble photo.</p>

        <div className="mt-6 flex flex-col md:flex-row gap-3 md:items-center">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search marble name or city..."
            className="flex-1 px-4 py-2 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
          />
          <div className="flex gap-2 flex-wrap">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`px-3 py-1.5 rounded-full text-sm border ${cat === c ? "bg-stone-900 text-white border-stone-900" : "bg-white border-stone-300"}`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {list.map((m) => (
            <div key={m.id} className="bg-white rounded-2xl overflow-hidden shadow hover:shadow-xl transition group">
              <div className="relative h-52 overflow-hidden cursor-pointer" onClick={() => setView(m)}>
                <img src={m.img} alt={m.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                <span className="absolute top-3 left-3 bg-white/90 text-xs px-2 py-1 rounded-full">{m.type}</span>
              </div>
              <div className="p-4">
                <h3 className="font-bold">{m.name}</h3>
                <p className="text-xs text-stone-500">📍 {m.origin}</p>
                <p className="text-sm mt-2 text-stone-600">{m.desc}</p>
                
                <div className="mt-4 flex gap-2">
                  <button onClick={() => download(m)} className="flex-1 px-3 py-2 rounded-lg bg-stone-900 text-white text-sm font-semibold hover:bg-stone-700">
                    ⬇ Download Photo
                  </button>
                  <a href={`tel:${CONTACT.phone}`} className="px-3 py-2 rounded-lg border border-stone-300 text-sm">Enquire</a>
                </div>
              </div>
            </div>
          ))}
        </div>
        {list.length === 0 && <p className="text-center text-stone-400 py-10">No marble found.</p>}
      </section>

      {/* Contact */}
      <section className="bg-stone-900 text-white py-16">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10">
          <div>
            <h2 className="text-3xl font-bold">Contact Us</h2>
            <p className="mt-3 text-stone-300">Visit our yard in Sirohi or call directly for best wholesale rates.</p>
            <div className="mt-6 space-y-2 text-lg">
              <p>👤 <strong>{CONTACT.owner}</strong></p>
              <p>📞 <a className="text-amber-300 font-semibold" href={`tel:${CONTACT.phone}`}>{CONTACT.phone}</a></p>
              <p>🏭 {CONTACT.firm}</p>
              <p>📍 {CONTACT.place}</p>
            </div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="font-semibold text-xl">Get a Quote</h3>
            <form
              className="mt-4 space-y-3"
              onSubmit={(e) => {
                e.preventDefault();
                const f = new FormData(e.currentTarget as HTMLFormElement);
                window.open(
                  `https://wa.me/91${CONTACT.phone}?text=` +
                    encodeURIComponent(`Hello Devendra ji, I am ${f.get("n")}. Requirement: ${f.get("m")}`),
                  "_blank"
                );
              }}
            >
              <input name="n" required placeholder="Your Name" className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 placeholder-stone-400" />
              <textarea name="m" required rows={3} placeholder="Marble requirement..." className="w-full px-4 py-2 rounded-lg bg-white/10 border border-white/20 placeholder-stone-400" />
              <button className="w-full py-2 rounded-lg bg-amber-400 text-stone-900 font-semibold">Send on WhatsApp</button>
            </form>
          </div>
        </div>
      </section>

      <footer className="bg-stone-950 text-stone-500 text-center py-6 text-sm">
        © {new Date().getFullYear()} RK Marble Sirohi · Devendra · {CONTACT.phone}
      </footer>

      {/* Lightbox */}
      {view && (
        <div className="fixed inset-0 z-50 bg-black/80 grid place-items-center p-4" onClick={() => setView(null)}>
          <div className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <img src={view.img} alt={view.name} className="w-full max-h-[60vh] object-cover" />
            <div className="p-5 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-lg">{view.name}</h3>
                <p className="text-sm text-stone-500">{view.origin}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => download(view)} className="px-4 py-2 rounded-lg bg-stone-900 text-white text-sm">⬇ Download</button>
                <button onClick={() => setView(null)} className="px-4 py-2 rounded-lg border text-sm">Close</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
