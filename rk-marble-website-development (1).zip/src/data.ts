export type Marble = {
  id: string;
  name: string;
  origin: string;
  type: string;
  img: string;
  desc: string;
};

const P = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200`;

export const marbles: Marble[] = [
  { id: "makrana-white", name: "Makrana White Marble", origin: "Makrana, Rajasthan", type: "White Marble", img: P(6634141), desc: "The legendary marble used in the Taj Mahal. Pure white, calcite rich and non-yellowing." },
  { id: "ambaji-white", name: "Ambaji White Marble", origin: "Ambaji, Gujarat", type: "White Marble", img: P(5623203), desc: "Bright milky white marble with fine crystals, ideal for temple and flooring work." },
  { id: "rajnagar-white", name: "Rajnagar White Marble", origin: "Rajsamand, Rajasthan", type: "White Marble", img: P(5623204), desc: "Economical white marble with light grey veins, widely used in Indian homes." },
  { id: "morwad-white", name: "Morwad White Marble", origin: "Morwad, Rajasthan", type: "White Marble", img: P(3847501), desc: "Smooth white base with soft grey shading, excellent polish and durability." },
  { id: "banswara-white", name: "Banswara White Marble", origin: "Banswara, Rajasthan", type: "Statuario Type", img: P(6634153), desc: "Indian statuario alternative with dramatic grey veining on a white background." },
  { id: "katni-beige", name: "Katni Beige Marble", origin: "Katni, Madhya Pradesh", type: "Beige Marble", img: P(4709046), desc: "Warm beige to yellow tones with rich patterns, very hard and long lasting." },
  { id: "udaipur-green", name: "Udaipur Green Marble", origin: "Rikhabdev, Udaipur", type: "Green Marble", img: P(18325723), desc: "Deep green marble with white veins, a classic Indian export favourite." },
  { id: "indian-grey", name: "Indian Grey Marble", origin: "Sirohi, Rajasthan", type: "Grey Marble", img: P(6634151), desc: "Elegant grey marble quarried near Sirohi, perfect for modern interiors." },
  { id: "black-marquina", name: "Indian Black Marquina", origin: "Bhainslana, Rajasthan", type: "Black Marble", img: P(5623224), desc: "Jet black marble with striking white veins, used for luxury feature walls." },
  { id: "onyx", name: "Indian Onyx Marble", origin: "Sirohi / Gujarat Belt", type: "Onyx", img: P(6634153), desc: "Translucent onyx slabs that glow beautifully with backlighting." },
  { id: "pink-marble", name: "Udaipur Pink Marble", origin: "Udaipur, Rajasthan", type: "Pink Marble", img: P(4709046), desc: "Soft pink marble traditionally used in Rajasthani palaces and havelis." },
  { id: "dungri", name: "Dungri White Marble", origin: "Sirohi, Rajasthan", type: "White Marble", img: P(6634141), desc: "Premium hard white marble from the Sirohi belt, stain resistant and bright." },
];

export const CONTACT = {
  owner: "Devendra",
  phone: "7297022722",
  firm: "RK Marble Sirohi",
  place: "Sirohi, Rajasthan, India",
};
