# Deploy RK Marble Sirohi on Vercel

Owner: Devendra · 📞 7297022722 · Sirohi, Rajasthan

---

## Option 1 — Fastest (no GitHub needed), using Vercel CLI

Open a terminal in this project folder (after unzipping `rk-marble-sirohi.zip`):

```bash
npm install -g vercel     # install Vercel CLI once
vercel login              # login with email / GitHub
vercel --prod             # deploy
```

Answer the prompts:
- Set up and deploy? **Y**
- Project name: **rk-marble-sirohi**
- Directory: **./**
- Override settings? **N** (vercel.json already configured)

After ~30 seconds you get your live link:
`https://rk-marble-sirohi.vercel.app`

---

## Option 2 — Via GitHub (recommended for future updates)

1. Create a new repo on https://github.com/new → name it `rk-marble-sirohi`
2. In this folder run:

```bash
git init
git add .
git commit -m "RK Marble Sirohi website"
git branch -M main
git remote add origin https://github.com/<your-username>/rk-marble-sirohi.git
git push -u origin main
```

3. Go to https://vercel.com/new → **Import Git Repository** → pick the repo
4. Vercel auto-detects Vite. Settings should be:
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. Click **Deploy** → live link appears in ~1 minute.

Every future `git push` auto-redeploys.

---

## Option 3 — Zero build (drag & drop the single HTML file)

The build output `dist/index.html` is a **single self-contained file** (CSS + JS inlined).

1. Make a new folder, copy only `dist/index.html` into it.
2. Run `vercel --prod` inside that folder, or drag the folder to
   https://vercel.com/new (Static preset) / https://app.netlify.com/drop.

---

## Custom domain (e.g. rkmarblesirohi.com)

Vercel Dashboard → your project → **Settings → Domains → Add** → enter domain →
update the A / CNAME records at your domain registrar as shown. SSL is automatic and free.
